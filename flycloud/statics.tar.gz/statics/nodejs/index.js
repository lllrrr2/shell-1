const express = require('express');
//const path = require('path');
//const fs = require('fs');
const bodyParser = require('body-parser');
const app = express();
app.use(bodyParser.json({ limit: '50mb' }));
app.use(bodyParser.urlencoded({ limit: '50mb', extended: true }));
app.all('*', function (req, res, next) {
    //设置允许跨域的域名，*代表允许任意域名跨域
    res.header("Access-Control-Allow-Origin","*");
    //允许的header类型
    res.header("Access-Control-Allow-Headers","content-type");
    //跨域允许的请求方式 
    res.header("Access-Control-Allow-Methods","DELETE,PUT,POST,GET,OPTIONS");
    if (req.method.toLowerCase() == 'options')
        res.send(200);  //让options尝试请求快速结束
    else
        next();
});

function timeFormat(time) {
  let date;
  if (time) {
    date = new Date(time);
  } else {
    date = new Date();
  }
  return (
    date.getFullYear() +
    '-' +
    (date.getMonth() + 1 >= 10
      ? date.getMonth() + 1
      : '0' + (date.getMonth() + 1)) +
    '-' +
    (date.getDate() >= 10 ? date.getDate() : '0' + date.getDate())
  );
}
const jdLib = require('./sms_login_encode.js');


async function sendSms(data) {
  const res = await jdLib.getVeriCode(data);
  return res;
}

async function checkCode(data) {
  const res = await jdLib.doTelLogin(data);
  return res;
}
/**
 * API 发验证码
 */
app.get('/sendSms', async function (request, response) {
  try {
    const phone = request.query.phone;
    if (!new RegExp('\\d{11}').test(phone)) {
      response.send({ ok: false, msg: '手机号格式错误' });
      return;
    }
    console.log('phone', phone);
    const user = await jdLib.init();
    console.log(user);
    user.mobile = phone;
    const res = await sendSms(user);
    // console.log(res);
    response.send({
      ok: res.err_code == 0,
      data: user,
      msg: res.err_msg || '成功',
    });
  } catch (err) {
    console.log(err);
    response.send({ ok: false, msg: '错误' });
  }
});

app.post('/checkCode', async function (request, response) {
  try {
    const phone = request.query.phone;
    if (!new RegExp('\\d{11}').test(phone)) {
      response.send({ ok: false, msg: '手机号格式错误' });
      return;
    }
    const code = request.query.code;
    if (!new RegExp('\\d{6}').test(code)) {
      response.send({ ok: false, msg: '验证码格式错误' });
      return;
    }
    const user = request.body;
    console.log('phone', phone, code);
    const res = await checkCode({
      gsalt: user.gsalt,
      guid: user.guid,
      lsid: user.lsid,
      mobile: phone,
      smscode: code,
    });
    // console.log(res);
    if (res.err_code != 0) {
      response.send({ ok: false, msg: '登录失败:' + res.err_msg });
    } else {
      const cookie =
        'pt_key=' +
        res.data.pt_key +
        ';pt_pin=' +
        encodeURIComponent(res.data.pt_pin) +
        ';';
      console.log('cookie', cookie);


      response.send({
        ok: true,
        msg: '获取ck成功',
        data: {
          ck: cookie,
        },
      });
    }
  } catch (err) {
    console.log(err);
    response.send({ ok: false, msg: '错误' });
  }
});

const sleep = (ms) => {
  return new Promise((resolve) => {
    setTimeout(resolve, ms);
  });
};

//app.use(express.static(path.join(__dirname, 'public')));

// 本地运行开启以下
const PORT = 24143;
app.listen(PORT, () => {
  console.log(`应用正在监听 ${PORT} 端口!`);
});

// 云函数运行开启以下
module.exports = app;
