
const jdLib = require('./sms_login_encode.js');



const args = process.argv.splice(2)




!(async() => {
	//调用发送验证码
	const args0 = args[0]
	var phone = args0.split("=")[1];
	//console.log(phone);
    const user = await jdLib.init();
    user.mobile = phone;
    const res = await sendSms(user);
	console.log(res)
})()
.catch((e) => {
	console.log('', `❌失败! 原因: ${e}!`, '')
})
.finally(() => {
	process.exit()
})


async function sendSms(data) {
  const res = await jdLib.getVeriCode(data);
  return res;
}




