
var cookies = {CookieJD0:'pt_key=AAJjW9XgADAlP8jrVl7v55jqsLE0SuBTSNo9zmL2DTjCqfaXbgHEU2WC4KQh1dOVUhllCZ5Ha18;pt_pin=jd_47e2d2c71c636;',}
var pins = process.env.pins
if(pins){
	pins = pins.split("&")
	for (var key in cookies) {
	    c = false
	    for (var pin of pins) {
		   if (pin && cookies[key].indexOf(pin) != -1) {
			  c = true
			  break
		   }
	    }
	    if (!c) {
		   delete cookies[key]
	    }
	}
}
module.exports = cookies